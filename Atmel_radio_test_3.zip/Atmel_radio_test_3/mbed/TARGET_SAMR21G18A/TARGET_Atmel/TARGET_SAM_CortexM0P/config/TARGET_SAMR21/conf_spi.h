#ifndef CONF_SPI_H_INCLUDED
#  define CONF_SPI_H_INCLUDED

#  define CONF_SPI_MASTER_ENABLE     true
#  define CONF_SPI_SLAVE_ENABLE      false
#  define CONF_SPI_TIMEOUT           10000

#endif /* CONF_SPI_H_INCLUDED */

